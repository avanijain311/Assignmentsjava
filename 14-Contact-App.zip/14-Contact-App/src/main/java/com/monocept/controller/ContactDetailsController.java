package com.monocept.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.monocept.entity.ContactDetails;
import com.monocept.service.ContactDetailsService;

@RestController
@RequestMapping("/contact-details")
public class ContactDetailsController {
    @Autowired
    private ContactDetailsService contactDetailsService;
    
    
    @PostMapping("/")
    public ContactDetails createContactDetails(@RequestBody ContactDetails contactDetails) {
        return contactDetailsService.createContactDetails(contactDetails);
    }
    
   
    @GetMapping("/{contactDetailsId}")
    public ContactDetails getContactDetails(@PathVariable Long contactDetailsId) {
        return contactDetailsService.getContactDetails(contactDetailsId);
    }
    
    
    @PutMapping("/{contactDetailsId}")
    public ContactDetails updateContactDetails(@PathVariable Long contactDetailsId, @RequestBody ContactDetails contactDetails) {
        return contactDetailsService.updateContactDetails(contactDetailsId, contactDetails);
    }
    
    
    @DeleteMapping("/{contactDetailsId}")
    public void deleteContactDetails(@PathVariable Long contactDetailsId) {
        contactDetailsService.deleteContactDetails(contactDetailsId);
    }
}

