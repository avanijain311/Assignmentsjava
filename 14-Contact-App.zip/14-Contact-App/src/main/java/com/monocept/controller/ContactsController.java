package com.monocept.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.monocept.entity.Contacts;
import com.monocept.service.ContactsService;

@RestController
@RequestMapping("/contacts")
public class ContactsController {
	@Autowired
	private ContactsService contactsService;

	@PostMapping("/")
	public Contacts createContact(@RequestBody Contacts contact) {
		return contactsService.createContact(contact);
	}

	@GetMapping("/{contactId}")
	public Contacts getContact(@PathVariable Long contactId) {
		return contactsService.getContact(contactId);
	}

	@PutMapping("/{contactId}")
	public Contacts updateContact(@PathVariable Long contactId, @RequestBody Contacts contact) {
		return contactsService.updateContact(contactId, contact);
	}

	@DeleteMapping("/{contactId}")
	public void deleteContact(@PathVariable Long contactId) {
		contactsService.deleteContact(contactId);
	}
}
