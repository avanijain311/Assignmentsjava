package com.monocept.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.monocept.entity.ContactDetails;
import com.monocept.repository.ContactDetailsRepository;

import jakarta.persistence.EntityNotFoundException;

@Service
public class ContactDetailsService {
    @Autowired
    private ContactDetailsRepository contactDetailsRepository;
    
    
    public ContactDetails createContactDetails(ContactDetails contactDetails) {
      
        return contactDetailsRepository.save(contactDetails);
    }
    
   
    public ContactDetails getContactDetails(Long contactDetailsId) {
        return contactDetailsRepository.findById(contactDetailsId)
                .orElseThrow(() -> new EntityNotFoundException("Contact details not found with ID: " + contactDetailsId));
    }
    
    
    public ContactDetails updateContactDetails(Long contactDetailsId, ContactDetails contactDetails) {
        
        ContactDetails existingContactDetails = getContactDetails(contactDetailsId);
        existingContactDetails.setAddress(contactDetails.getAddress());
        existingContactDetails.setCity(contactDetails.getCity());
        existingContactDetails.setZipCode(contactDetails.getZipCode());
        
        return contactDetailsRepository.save(existingContactDetails);
    }
    
    
    public void deleteContactDetails(Long contactDetailsId) {
        ContactDetails existingContactDetails = getContactDetails(contactDetailsId);
        contactDetailsRepository.delete(existingContactDetails);
    }
}
