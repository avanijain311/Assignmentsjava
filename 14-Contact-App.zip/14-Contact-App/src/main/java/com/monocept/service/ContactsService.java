package com.monocept.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.monocept.entity.Contacts;
import com.monocept.repository.ContactsRepository;

import jakarta.persistence.EntityNotFoundException;

@Service
public class ContactsService {
	@Autowired
	private ContactsRepository contactsRepository;

	public Contacts createContact(Contacts contact) {

		return contactsRepository.save(contact);
	}

	public Contacts getContact(Long contactId) {
		return contactsRepository.findById(contactId)
				.orElseThrow(() -> new EntityNotFoundException("Contact not found with ID: " + contactId));
	}

	public Contacts updateContact(Long contactId, Contacts contact) {

		Contacts existingContact = getContact(contactId);
		existingContact.setName(contact.getName());
		existingContact.setEmail(contact.getEmail());
		existingContact.setPhone(contact.getPhone());
		return contactsRepository.save(existingContact);
	}

	public void deleteContact(Long contactId) {
		Contacts existingContact = getContact(contactId);
		contactsRepository.delete(existingContact);
	}
}
