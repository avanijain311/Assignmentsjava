package com.monocept.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.monocept.entity.User;
import com.monocept.repository.UserRepository;

import jakarta.persistence.EntityNotFoundException;

@Service
public class UserService {
	@Autowired
	private UserRepository userRepository;

	public User createUser(User user) {

		return userRepository.save(user);
	}

	public User getUser(Long userId) {
		return userRepository.findById(userId)
				.orElseThrow(() -> new EntityNotFoundException("User not found with ID: " + userId));
	}

	public User updateUser(Long userId, User user) {

		User existingUser = getUser(userId);
		existingUser.setName(user.getName());
		existingUser.setRole(user.getRole());
		return userRepository.save(existingUser);
	}

	public void deleteUser(Long userId) {
		User existingUser = getUser(userId);
		userRepository.delete(existingUser);
	}
}
