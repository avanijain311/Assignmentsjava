package com.monocept.repository;


import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.monocept.entity.Bank;

@Repository
public interface BankRepository extends JpaRepository<Bank, Long> {    

	Optional<Bank> findByBankName (String bankName);
	Optional<Bank> findByBankId (Long bankId);
	List<Bank> findByAbbreviation(String abbreviation);
	
}