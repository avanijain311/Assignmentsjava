package com.monocept.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.monocept.entity.Account;
import com.monocept.entity.Transaction;
import com.monocept.service.AccountService;

@RestController
@RequestMapping("/accounts")
public class AccountController {

	@Autowired
	private AccountService accountService;

	@GetMapping("/{accountId}")
	public ResponseEntity<Account> getAccountById(@PathVariable Long accountId) {
		Account account = accountService.getAccountById(accountId);
		if (account != null) {
			return ResponseEntity.ok(account);
		} else {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
		}
	}

	@GetMapping("/{accountId}/balance")
	public ResponseEntity<Double> getAccountBalance(@PathVariable Long accountId) {
		Double balance = accountService.getAccountBalance(accountId);
		if (balance != null) {
			return ResponseEntity.ok(balance);
		} else {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
		}
	}

	@GetMapping("/{accountId}/transactions")
	public ResponseEntity<List<Transaction>> getAccountTransactions(@PathVariable Long accountId) {
		List<Transaction> transactions = accountService.getAccountTransactions(accountId);
		if (transactions != null) {
			return ResponseEntity.ok(transactions);
		} else {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
		}
	}

	@PostMapping("/{accountId}/deposit")
	public ResponseEntity<Account> depositToAccount(@PathVariable Long accountId, @RequestBody Float amount) {
		Account account = accountService.depositToAccount(accountId, amount);
		if (account != null) {
			return ResponseEntity.ok(account);
		} else {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
		}
	}

	@PostMapping("/{accountId}/withdraw")
	public ResponseEntity<Account> withdrawFromAccount(@PathVariable Long accountId, @RequestBody Float amount) {
		Account account = accountService.withdrawFromAccount(accountId, amount);
		if (account != null) {
			return ResponseEntity.ok(account);
		} else {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
		}
	}

	@PostMapping("/{sourceAccountId}/transfer/{targetAccountId}")
	public ResponseEntity<Transaction> transferBetweenAccounts(@PathVariable Long sourceAccountId,
			@PathVariable Long targetAccountId, @RequestBody Float amount) {
		Transaction transaction = accountService.transferBetweenAccounts(sourceAccountId, targetAccountId, amount);
		if (transaction != null) {
			return ResponseEntity.ok(transaction);
		} else {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
		}
	}
}
