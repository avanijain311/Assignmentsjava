package com.monocept.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.monocept.entity.Account;
import com.monocept.entity.Transaction;
import com.monocept.service.AccountService;

@RestController
@RequestMapping("/api/bank")
public class BankController {

	@Autowired
	private AccountService accountService;

	@PostMapping("/accounts")
	public ResponseEntity<Account> createAccount(@RequestBody Account account) {
		Account createdAccount = accountService.createAccount(account);
		return ResponseEntity.status(HttpStatus.CREATED).body(createdAccount);
	}

	@GetMapping("/accounts/{accountId}")
	public ResponseEntity<Account> getAccountById(@PathVariable Long accountId) {
		Account account = accountService.getAccountById(accountId);
		if (account != null) {
			return ResponseEntity.ok(account);
		} else {
			return ResponseEntity.notFound().build();
		}
	}

	@GetMapping("/accounts")
	public ResponseEntity<List<Account>> getAllAccounts() {
		List<Account> accounts = accountService.getAllAccounts();
		return ResponseEntity.ok(accounts);
	}

	@PostMapping("/accounts/{accountId}/transactions")
	public ResponseEntity<Transaction> createTransaction(@PathVariable Long accountId, @RequestBody Transaction transaction) {
		Transaction createdTransaction = accountService.createTransaction(accountId, transaction);
		return ResponseEntity.status(HttpStatus.CREATED).body(createdTransaction);
	}

	@GetMapping("/accounts/{accountId}/transactions")
	public ResponseEntity<List<Transaction>> getTransactionsByAccountId(@PathVariable Long accountId) {
		List<Transaction> transactions = accountService.getTransactionsByAccountId(accountId);
		return ResponseEntity.ok(transactions);
	}

	@GetMapping("/transactions")
	public ResponseEntity<List<Transaction>> getAllTransactions() {
		List<Transaction> transactions = accountService.getAllTransactions();
		return ResponseEntity.ok(transactions);
	}
}
