package com.monocept.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.monocept.entity.Account;
import com.monocept.entity.Transaction;
import com.monocept.repository.AccountRepository;
import com.monocept.repository.TransactionRepository;

@Service
public class AccountService {

	@Autowired
	private AccountRepository accountRepository;

	@Autowired
	private TransactionRepository transactionRepository;

	public Account getAccountById(Long accountId) {
		return accountRepository.findById(accountId).orElse(null);
	}

	public Double getAccountBalance(Long accountId) {
		Account account = accountRepository.findById(accountId).orElse(null);
		if (account != null) {
			return account.getBalance();
		} else {
			return null;
		}
	}

	public List<Transaction> getAccountTransactions(Long accountId) {
		return transactionRepository.findBytID(accountId);
	}

	public Account depositToAccount(Long accountId, Float amount) {
		Account account = accountRepository.findById(accountId).orElse(null);
		if (account != null) {
			account.setBalance(account.getBalance() + amount);
			account = accountRepository.save(account);
			return account;
		} else {
			return null;
		}
	}

	public Account withdrawFromAccount(Long accountId, Float amount) {
		Account account = accountRepository.findById(accountId).orElse(null);
		if (account != null) {
			if (account.getBalance() >= amount) {
				account.setBalance(account.getBalance() - amount);
				account = accountRepository.save(account);
				return account;
			} else {
				return null;
			}
		} else {
			return null;
		}
	}

	public Transaction transferBetweenAccounts(Long sourceAccountId, Long targetAccountId, Float amount) {
		Account sourceAccount = accountRepository.findById(sourceAccountId).orElse(null);
		Account targetAccount = accountRepository.findById(targetAccountId).orElse(null);
		if (sourceAccount != null && targetAccount != null) {
			if (sourceAccount.getBalance() >= amount) {
				sourceAccount.setBalance(sourceAccount.getBalance() - amount);
				targetAccount.setBalance(targetAccount.getBalance() + amount);
				sourceAccount = accountRepository.save(sourceAccount);
				targetAccount = accountRepository.save(targetAccount);

				Transaction transaction = new Transaction();
				transaction = transactionRepository.save(transaction);

				return transaction;
			} else {
				return null;
			}
		} else {
			return null;
		}
	}

	public List<Account> getAllAccounts() {
		return accountRepository.findAll();
	}

	public Transaction createTransaction(Long accountId, Transaction transaction) {
		Account account = accountRepository.findById(accountId).orElse(null);
		if (account != null) {
			transaction.setAccount(account);
			transaction = transactionRepository.save(transaction);
			return transaction;
		} else {
			return null;
		}
	}

	public List<Transaction> getTransactionsByAccountId(Long accountId) {
		return transactionRepository.findBytID(accountId);
	}

	public List<Transaction> getAllTransactions() {
		return transactionRepository.findAll();
	}

	public Account createAccount(Account account) {
		return accountRepository.save(account);
	}

}
