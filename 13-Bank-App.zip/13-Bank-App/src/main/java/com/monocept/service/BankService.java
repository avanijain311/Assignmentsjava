package com.monocept.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.monocept.entity.Bank;
import com.monocept.repository.BankRepository;

@Service
public class BankService {

	@Autowired
	private BankRepository bankRepository;

	public Bank createBank(Bank bank) {

		List<Bank> existingBank = bankRepository.findByAbbreviation(bank.getAbbreviation());
		if (existingBank != null) {

			throw new RuntimeException("Bank with the same bank code already exists.");
		}
		return bankRepository.save(bank);
	}

	public Bank getBankById(Long bankId) {

		return bankRepository.findById(bankId).orElse(null);
	}

	public List<Bank> getBankByBankCode(String bankCode) {
		return bankRepository.findByAbbreviation(bankCode);
	}

	public Optional<Bank> getBankByBankName(String bankName) {

		return bankRepository.findByBankName(bankName);
	}

	public List<Bank> getAllBanks() {

		return bankRepository.findAll();
	}

	public Bank updateBank(Bank bank) {
		return bankRepository.save(bank);
	}

	public void deleteBankById(Long bankId) {
		bankRepository.deleteById(bankId);
	}
}
