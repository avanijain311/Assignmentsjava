package com.monocept.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.monocept.entity.Transaction;
import com.monocept.repository.TransactionRepository;

@Service
public class TransactionService {

	@Autowired
	private TransactionRepository transactionRepository;

	public Transaction getTransactionById(Long transactionId) {
		return transactionRepository.findById(transactionId).orElse(null);
	}

	public List<Transaction> getAllTransactions() {
		return transactionRepository.findAll();
	}

	public Transaction createTransaction(Transaction transaction) {
		return transactionRepository.save(transaction);
	}

	public Transaction updateTransaction(Long transactionId, Transaction transaction) {
		Optional<Transaction> optionalTransaction = transactionRepository.findById(transactionId);
		if (optionalTransaction.isPresent()) {
			Transaction existingTransaction = optionalTransaction.get();
			return transactionRepository.save(existingTransaction);
		} else {
			return null;
		}
	}

	public boolean deleteTransaction(Long transactionId) {
		Optional<Transaction> optionalTransaction = transactionRepository.findById(transactionId);
		if (optionalTransaction.isPresent()) {
			transactionRepository.deleteById(transactionId);
			return true;
		} else {
			return false;
		}
	}
}
