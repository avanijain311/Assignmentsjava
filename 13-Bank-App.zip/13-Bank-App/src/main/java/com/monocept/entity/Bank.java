package com.monocept.entity;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;


@Entity
public class Bank {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	Long bankId;
	String bankName;
	String abbreviation;

	@OneToMany(mappedBy = "bank")
	@JsonManagedReference
	private List<Account> accounts;


	public Bank() {
		super();
	}

	public Bank(Long bankId, String bankName, String abbriviation, List<Account> accounts) {
		super();
		this.bankId = bankId;
		this.bankName = bankName;
		this.abbreviation = abbriviation;
		this.accounts = accounts;
	}

	public Long getBankId() {
		return bankId;
	}

	public void setBankId(Long bankId) {
		this.bankId = bankId;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getAbbreviation() {
		return abbreviation;
	}

	public void setAbbreviation(String abbreviation) {
		this.abbreviation = abbreviation;
	}

	public List<Account> getAccounts() {
		return accounts;
	}

	public void setAccounts(List<Account> accounts) {
		this.accounts = accounts;
	}
	
	
}
