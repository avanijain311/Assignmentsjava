package com.monocept.entity;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;

@Entity
public class Account {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long accountNo;
 
 
    //foreign key
  	@ManyToOne(cascade = CascadeType.ALL)	
  	@JoinColumn(name = "customerId", referencedColumnName="userId")
  	@JsonBackReference
  	private User user;
  	
    //foreign key
  	@ManyToOne(cascade = CascadeType.ALL)	
  	@JoinColumn(name = "bankId", referencedColumnName="bankId")
  	@JsonBackReference
  	private Bank bank;
  	
  	
	@OneToMany(mappedBy = "account")
	@JsonManagedReference
	private List<Transaction> transfer;
	
	@OneToMany(mappedBy = "reciver")
	@JsonManagedReference
	private List<Transaction> recived;
	
	private Double balance;
	
	public Double getBalance() {
		return balance;
	}


	public void setBalance(Double balance) {
		this.balance = balance;
	}


	public Account() {
		super();
	}


	public Account(Long accountNo, User user, Bank bank, List<Transaction> transfer, List<Transaction> recived, Double balance) {
		super();
		this.accountNo = accountNo;
		this.user = user;
		this.bank = bank;
		this.transfer = transfer;
		this.recived = recived;
		this.balance = balance; 
	}


	public Long getAccountNo() {
		return accountNo;
	}


	public void setAccountNo(Long accountNo) {
		this.accountNo = accountNo;
	}


	public User getUser() {
		return user;
	}


	public void setUser(User user) {
		this.user = user;
	}


	public Bank getBank() {
		return bank;
	}


	public void setBank(Bank bank) {
		this.bank = bank;
	}


	public List<Transaction> getTransfer() {
		return transfer;
	}


	public void setTransfer(List<Transaction> transfer) {
		this.transfer = transfer;
	}


	public List<Transaction> getRecived() {
		return recived;
	}


	public void setRecived(List<Transaction> recived) {
		this.recived = recived;
	}
	
	
}
