package com.monocept.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Transaction {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long tID;
	private Float amount;
	
	@ManyToOne(cascade = CascadeType.ALL)	
  	@JoinColumn(name = "senderAccID", referencedColumnName="accountNo")
  	@JsonBackReference
  	private Account account;
  	
  	@ManyToOne(cascade = CascadeType.ALL)	
  	@JoinColumn(name = "reciverAccId", referencedColumnName="accountNo")
  	@JsonBackReference
  	private Account reciver;

	public Transaction() {
		super();
	}

	public Transaction(Long tID, Float amount, Account account, Account reciver) {
		super();
		this.tID = tID;
		this.amount = amount;
		this.account = account;
		this.reciver = reciver;
	}

	public Long gettID() {
		return tID;
	}

	public void settID(Long tID) {
		this.tID = tID;
	}

	public Float getAmount() {
		return amount;
	}

	public void setAmount(Float amount) {
		this.amount = amount;
	}

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	public Account getReciver() {
		return reciver;
	}

	public void setReciver(Account reciver) {
		this.reciver = reciver;
	}
  	
  	
  	
}
